from models.DashboardFactory import DashboardFactory 
from app import app,db
from flask import render_template,redirect,request,url_for
from models import card,user,account
from models.card import Creditcard
from models.account import Account
from models.CustomerApplications import CustomerApplication
from models.user import User
import datetime
from datetime import date
from passgen import Randpass
@app.route("/EmployeeDashboard", methods=['GET','POST'])
def EmployeeDashboard():
    flag=0
    df = DashboardFactory()
    dashObj = df.getDashboard("Employee") #Employee/Customer/Admin
    data = dashObj.GetDashboardData()
    #using random generator for pin,cardNo,ExpiryDate
    print(data.applications)
    if request.method=='GET':
        print("yes")
        if request.form.get('submit'):
            print("inside")
    #if request.method=="GET" and flag==0:
            for i in data.applications:
                randomVar=Randpass()
                passwd=randomVar.passGen()
                pin=randomVar.pinGen() 
                cardNo=randomVar.cardGen()  
                expDate=randomVar.cardExp()
                acno=randomVar.accGen()
                userId=randomVar.userGen()
                opendate=date.today()
                c=Creditcard(cardNo,pin,12,expDate,1,i.CARDTYPE)
                c.addCard()
                a=Account(acno,userId,cardNo,opendate,1000,550,'open')
                a.addAccount()
                u=User(userId,acno,"username",passwd,i.FIRSTNAME,i.LASTNAME,"customer",i.DOB,"email@test.com",i.ADDRESS,i.CITY,893930,i.OCCUPATION,i.MONTHLYINCOME)
                u.addUser()
                flag=1  


    return(render_template(data.template,data = data))    
