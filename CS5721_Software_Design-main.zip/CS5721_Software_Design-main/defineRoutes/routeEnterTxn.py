from app import app
from flask import render_template,redirect,url_for,flash,request
from models.Transactions import Transaction
import forms
@app.route("/Enter_Transaction",methods=['POST','GET'])
def Enter_Transaction():
    form=forms.EnterTransactionForm()
    if form.validate_on_submit():
        txn=Transaction(cardNumber=form.CARD_NUMBER.data,transactionType=form.TRANSACTION_TYPE.data,transactionSource=form.TRANSACTION_SOURCE.data,timestamp=form.TIMESTAMP.data,amount=form.AMOUNT.data)
        txn.addTransaction()
        return redirect(url_for('Enter_Transaction'))
    return(render_template('Enter_Txn.html',form=form))  