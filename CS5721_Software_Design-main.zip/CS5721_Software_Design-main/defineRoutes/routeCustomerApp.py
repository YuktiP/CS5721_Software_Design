from app import app
from flask import render_template,redirect,url_for,flash,request
from models.CustomerApplications import CustomerApplication
import forms

@app.route("/Customer_Application",methods=['POST','GET'])
def Customer_Application():
    form=forms.CustomerApplicantForm()
    if form.validate_on_submit():
        custapp=CustomerApplication(ID=ID.data,FIRSTNAME=FIRSTNAME.data,LASTNAME=LASTNAME.data,ADDRESS=ADDRESS.data,DOB=DOB.data,CITY=CITY.data,ZIPCODE=ZIPCODE.data,OCCUPATION=OCCUPATION.data,MONTHLYINCOME=MONTHLYINCOME.data,CARDTYPE=CARDTYPE.data)
        custapp.Create_Cust_Application()
        return redirect(url_for('Customer_Application'))
    return(render_template('Customer_App.html',form=form))