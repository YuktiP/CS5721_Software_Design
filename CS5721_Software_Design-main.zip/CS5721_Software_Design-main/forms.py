from flask_wtf import FlaskForm
from wtforms import StringField,SubmitField,IntegerField,PasswordField,validators,DateTimeField,DateField
from flask import Flask, request
from wtforms.validators import (
    DataRequired,
    Email,
    EqualTo,
    Length,
    Optional
)

class EnrollForm(FlaskForm):
    FIRSTNAME=StringField('FNAME')
    SURNAME=StringField('SNAME')
    EMAIL=StringField('EMAIL')
    ADDRESS=StringField('ADDR')
    SUBMIT=SubmitField('SUBMIT')

class Login(FlaskForm):
    EMAIL = StringField('EMAIL')
    PASSWORD = PasswordField('PASSWORD')
    SUBMIT = SubmitField('SUBMIT')

class EnterTransactionForm(FlaskForm):
    
    CARD_NUMBER=StringField('CARD_NUMBER')
    TRANSACTION_TYPE=StringField('TRANSACTION_TYPE')
    TRANSACTION_SOURCE=StringField('TRANSACTION_SOURCE')
    TIMESTAMP=DateTimeField('TIMESTAMP')
    AMOUNT=IntegerField('AMOUNT')
    SUBMIT=SubmitField('SUBMIT')

class CustomerApplicantForm(FlaskForm):
    ID=IntegerField('ID')
    FIRSTNAME = StringField('FIRSTNAME')
    LASTNAME = StringField('LASTNAME')
    ADDRESS = StringField('ADDRESS')
    DOB=DateField('DOB')
    CITY=StringField('CITY')
    ZIPCODE=StringField('ZIPCODE')
    OCCUPATION=StringField('OCCUPATION')
    MONTHLYINCOME=IntegerField('MONTHLYINCOME')
    CARDTYPE=StringField('CARDTYPE')
    SUBMIT=SubmitField('SUBMIT')

class Buttonform(FlaskForm):
    SUBMIT=SubmitField('ONBOARD') 
