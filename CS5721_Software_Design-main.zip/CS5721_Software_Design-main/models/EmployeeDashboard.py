from Interfaces.IDashboard import IDashboard
from models.CustomerApplications import *
from flask import request, redirect, url_for
import passgen
from app import db
import forms

class EmployeeDashboard(IDashboard):

    def __init__(self):
        self=self

    def GetDashboardData(self):
        result=db.session.query(CustomerApplication).all()
        self.dashboardName = "Display a List of Customers to be onboarded"
        print(result)
        for i in result :
            print(i.FIRSTNAME)
        
        self.template = "OnBoardCustomers.html"
        self.applications = result

        return self


            



            
        
    