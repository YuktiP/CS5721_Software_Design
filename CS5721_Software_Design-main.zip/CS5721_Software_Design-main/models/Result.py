class Result():

    def __init__(self, isSuccess = False, text=""):
        self.isSuccess = isSuccess
        self.text = text
    


