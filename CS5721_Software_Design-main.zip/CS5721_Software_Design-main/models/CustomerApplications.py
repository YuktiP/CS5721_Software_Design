from app import db

class CustomerApplication(db.Model):

    ID=db.Column(db.Integer,primary_key=True)
    FIRSTNAME=db.Column(db.String(20))
    LASTNAME=db.Column(db.String(20))
    ADDRESS=db.Column(db.String(40))
    DOB=db.Column(db.Date)
    CITY=db.Column(db.String(20))
    ZIPCODE=db.Column(db.String(20))
    OCCUPATION=db.Column(db.String(20))
    MONTHLYINCOME=db.Column(db.Integer)
    CARDTYPE=db.Column(db.String(20))

    def __init__(self,ID,FIRSTNAME,LASTNAME,ADDRESS,DOB,CITY,ZIPCODE,OCCUPATION,MONTHLYINCOME,CARDTYPE):
        self.ID =ID
        self.FIRSTNAME = FIRSTNAME
        self.LASTNAME = LASTNAME
        self.ADDRESS = ADDRESS
        self.DOB=DOB
        self.CITY=CITY
        self.ZIPCODE=ZIPCODE
        self.OCCUPATION=OCCUPATION
        self.MONTHLYINCOME=MONTHLYINCOME
        self.CARDTYPE=CARDTYPE

    def Create_Cust_Application(self):
        db.create_all()
        db.session.add(self)
        db.session.commit()