from Result import Result
from Interfaces import IAuthorization

class UserAuthorization(IAuthorization):
    
    def Authorize(UserId):
        


